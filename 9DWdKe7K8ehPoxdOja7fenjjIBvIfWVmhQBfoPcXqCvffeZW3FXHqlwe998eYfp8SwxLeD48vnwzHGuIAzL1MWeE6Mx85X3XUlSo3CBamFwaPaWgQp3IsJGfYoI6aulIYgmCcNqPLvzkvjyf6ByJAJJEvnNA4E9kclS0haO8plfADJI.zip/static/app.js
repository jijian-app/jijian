// ========== 全局状态 ==========
let currentTab = 'chat';
let testStep = 0;
let testScores = [];
let selectedMood = null;

// ========== 启动页 ==========
setTimeout(() => {
    const splash = document.getElementById('splash-screen');
    const app = document.getElementById('app');
    splash.classList.add('fade-out');
    setTimeout(() => {
        splash.style.display = 'none';
        app.classList.remove('hidden');
    }, 800);
}, 2000);

// ========== Tab 切换 ==========
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        const tabId = 'tab-' + tab.dataset.tab;
        document.getElementById(tabId).classList.add('active');
        currentTab = tab.dataset.tab;
    });
});

// ========== 对话功能 ==========
const chatInput = document.getElementById('chatInput');
const chatSend = document.getElementById('chatSend');
const chatMessages = document.getElementById('chatMessages');

chatSend.addEventListener('click', sendMessage);
chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

function sendMessage() {
    const text = chatInput.value.trim();
    if (!text) return;

    // 添加用户消息
    addMessage(text, 'user');
    chatInput.value = '';

    // AI 回复
    setTimeout(() => {
        const reply = getAIReply(text);
        addMessage(reply, 'ai');
    }, 800 + Math.random() * 1000);
}

function addMessage(text, type) {
    const div = document.createElement('div');
    div.className = `message ${type}`;
    const avatar = type === 'ai' ? '🌱' : '😊';
    div.innerHTML = `<div class="avatar">${avatar}</div><div class="bubble">${text}</div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function getAIReply(text) {
    const t = text.toLowerCase();
    const positiveWords = ['开心', '高兴', '快乐', '好', '棒', '厉害', '不错', '可以'];
    const negativeWords = ['难过', '伤心', '焦虑', '压力', '烦', '累', '无聊', '孤独', '郁闷', '压抑', '不开心', '迷茫', '害怕', '担心'];
    const questionWords = ['怎么办', '怎么', '为什么', '如何', '能不能', '是否'];

    if (positiveWords.some(w => t.includes(w))) {
        const replies = [
            '太好了！🎉 能感受到你的积极能量，继续保持！你值得一切美好~',
            '你的好心情真的很有感染力呢！✨ 记住这种感觉，它是你最好的伙伴。',
            '听到你开心我也很开心！😊 好好享受这一刻，你配得上所有快乐！',
            '棒棒哒！🌟 快乐是一种能力，而你已经很擅长了~'
        ];
        return replies[Math.floor(Math.random() * replies.length)];
    }

    if (negativeWords.some(w => t.includes(w))) {
        const replies = [
            '我能感受到你现在的状态 🫂 想告诉你：有这些感受是完全正常的，不需要对自己太苛刻。',
            '谢谢你愿意告诉我这些 💜 低谷只是暂时的，你比你想象的更坚强。要不要试试记录一下现在的感受？',
            '你说的这些，很多人都在经历，但你选择说出来，这本身就是一种勇气 🌱 我一直在。',
            '嗯，我听到了 🤗 有时候，被看见、被理解就是最好的安慰。你不需要独自承担。',
            '现在的你辛苦了 💙 深呼吸三次，告诉自己：这只是暂时的，而我会一直在你身边。'
        ];
        return replies[Math.floor(Math.random() * replies.length)];
    }

    if (questionWords.some(w => t.includes(w))) {
        const replies = [
            '这个问题很好 🤔 让我们一起想想...你内心其实已经有答案了，只是还没发现它。你直觉觉得呢？',
            '嗯，我理解你的困惑 💭 有时候答案不是想出来的，而是慢慢浮现的。给自己一点时间~',
            '这个问题值得好好想想 ✨ 你可以试试换一个角度：如果好朋友遇到同样的情况，你会怎么说？',
            '你的思考本身就在靠近答案 🌟 不着急，先让自己放松下来，答案会更清晰。'
        ];
        return replies[Math.floor(Math.random() * replies.length)];
    }

    // 默认回复
    const defaults = [
        '我在听呢 💚 继续说，我不会走开的。',
        '谢谢你和我分享 🌸 想聊什么都可以，我都在。',
        '嗯嗯，我理解 ✨ 你还有什么想说的吗？',
        '你说的我都记在心里了 💝 继续吧，我在~',
        '我在呢 🌷 不管什么时候，我都在这里等你。'
    ];
    return defaults[Math.floor(Math.random() * defaults.length)];
}

// ========== 塔罗功能 ==========
const tarotCards = [
    { name: '愚者', emoji: '🃏', meaning: '新的开始，无限可能。你现在正站在新旅程的起点，勇敢迈出第一步吧！每一段伟大的故事，都从一次勇敢的尝试开始。' },
    { name: '魔术师', emoji: '🎩', meaning: '你拥有将想法变为现实的力量。你所需要的资源就在手边，相信自己的能力，现在就是行动的最好时机！' },
    { name: '女祭司', emoji: '🌙', meaning: '相信你的直觉。内心深处的声音正在指引你，安静下来，聆听自己，答案就在你的心中。' },
    { name: '皇后', emoji: '👑', meaning: '丰盛与滋养正在向你走来。你值得被爱、被照顾，允许自己享受生活的美好吧！' },
    { name: '星星', emoji: '⭐', meaning: '希望正在闪耀。即使现在处于黑夜，星光也在为你指引方向。保持信念，美好正在路上。' },
    { name: '太阳', emoji: '☀️', meaning: '光明与温暖！一切都在向好的方向发展，你的努力正在开花结果，享受这份喜悦吧！' },
    { name: '世界', emoji: '🌍', meaning: '圆满与完成。你正在经历一个重要的里程碑，为自己骄傲吧，你已经走了很远！' },
    { name: '力量', emoji: '🦁', meaning: '内在的力量比你想象的更强大。温柔而坚定地面对挑战，你比你以为的更有力量。' },
    { name: '命运之轮', emoji: '🎡', meaning: '转机即将来临。变化是生活的调味品，拥抱改变，好运正在向你转动！' },
    { name: '节制', emoji: '⚖️', meaning: '平衡是当下的关键词。不急不躁，找到属于自己的节奏，一切都会恰到好处。' },
    { name: '月亮', emoji: '🌕', meaning: '有些事情还没有完全清晰，但这没关系。给自己时间，迷雾终将散去，真相会浮现。' },
    { name: '正义', emoji: '⚔️', meaning: '公正与真相。你做的是对的事，宇宙会回报你的真诚与善良。继续做自己！' }
];

function drawTarot() {
    const card = tarotCards[Math.floor(Math.random() * tarotCards.length)];
    document.getElementById('drawBtn').classList.add('hidden');
    const resultDiv = document.getElementById('tarotResult');
    resultDiv.classList.remove('hidden');

    document.getElementById('tarotCardDisplay').textContent = card.emoji;
    document.getElementById('tarotReading').innerHTML = `
        <div style="text-align:center;font-size:1.3rem;font-weight:600;margin-bottom:12px;">${card.name}</div>
        <div>${card.meaning}</div>
    `;
}

// ========== 国学功能 ==========
const guoxueData = [
    { text: '天行健，君子以自强不息。', source: '《周易·乾卦》', insight: '宇宙在不停运转，你也一样。每一步坚持，都是在积蓄力量。' },
    { text: '知者不惑，仁者不忧，勇者不惧。', source: '《论语·子罕》', insight: '你现在走的路，需要的就是这份不惑、不忧、不惧的勇气。' },
    { text: '山重水复疑无路，柳暗花明又一村。', source: '陆游《游山西村》', insight: '眼前的困难只是暂时的，转角处就有新的希望。' },
    { text: '长风破浪会有时，直挂云帆济沧海。', source: '李白《行路难》', insight: '你的那片海，正在等你的帆。耐心等待，属于你的风终会来。' },
    { text: '千磨万击还坚劲，任尔东西南北风。', source: '郑燮《竹石》', insight: '像竹子一样，扎根深处，外界的风雨撼动不了你内心的坚定。' },
    { text: '行到水穷处，坐看云起时。', source: '王维《终南别业》', insight: '走到尽头不是终点，而是新风景的起点。放平心态，静待云开。' },
    { text: '不畏浮云遮望眼，自缘身在最高层。', source: '王安石《登飞来峰》', insight: '站得够高，眼前的遮挡就不是问题。提升视角，困局会变成风景。' },
    { text: '海纳百川，有容乃大；壁立千仞，无欲则刚。', source: '林则徐', insight: '心宽则事小，放下执念，内心自然强大。' },
    { text: '宝剑锋从磨砺出，梅花香自苦寒来。', source: '《警世贤文》', insight: '现在的辛苦，是在打磨最好的你。所有磨砺，终将绽放。' },
    { text: '莫听穿林打叶声，何妨吟啸且徐行。', source: '苏轼《定风波》', insight: '风雨中的从容，才是真正的力量。慢慢走，不着急。' }
];

function drawGuoxue() {
    const item = guoxueData[Math.floor(Math.random() * guoxueData.length)];
    document.getElementById('guoxueText').innerHTML = `「${item.text}」`;
    document.getElementById('guoxueSource').textContent = `—— ${item.source}`;
    document.getElementById('guoxueSource').innerHTML += `<div style="margin-top:16px;padding-top:16px;border-top:1px solid rgba(167,139,250,0.1);color:#e8e8f0;font-style:normal;line-height:1.8;">💡 ${item.insight}</div>`;
}

// ========== 心理测试 ==========
const testQuestions = [
    {
        q: '最近一周，你多久会感到心情低落？',
        options: ['几乎没有', '偶尔', '有时', '经常', '几乎每天']
    },
    {
        q: '你对日常活动（工作、学习、社交）的兴趣如何？',
        options: ['非常感兴趣', '比较感兴趣', '一般', '兴趣减少', '完全没兴趣']
    },
    {
        q: '你对自己的睡眠质量评价如何？',
        options: ['很好', '较好', '一般', '较差', '很差']
    },
    {
        q: '遇到困难时，你觉得有人可以倾诉吗？',
        options: ['有很多人', '有一些人', '只有一两个', '几乎没有', '完全没有']
    },
    {
        q: '你觉得自己是有价值的吗？',
        options: ['非常有价值', '比较有价值', '一般', '不太觉得', '完全没感觉']
    }
];

function startTest() {
    testStep = 0;
    testScores = [];
    document.getElementById('testResult').classList.add('hidden');
    document.getElementById('testContent').classList.remove('hidden');
    showQuestion();
}

function showQuestion() {
    if (testStep >= testQuestions.length) {
        showTestResult();
        return;
    }
    const q = testQuestions[testStep];
    document.getElementById('testQuestion').textContent = `${testStep + 1}/${testQuestions.length}  ${q.q}`;
    const optionsDiv = document.getElementById('testOptions');
    optionsDiv.innerHTML = '';
    q.options.forEach((opt, i) => {
        const btn = document.createElement('div');
        btn.className = 'test-option';
        btn.textContent = opt;
        btn.onclick = () => {
            testScores.push(i);
            testStep++;
            showQuestion();
        };
        optionsDiv.appendChild(btn);
    });
}

function showTestResult() {
    document.getElementById('testContent').classList.add('hidden');
    document.getElementById('testResult').classList.remove('hidden');

    const total = testScores.reduce((a, b) => a + b, 0);
    const max = testQuestions.length * 4;
    const percent = Math.round((1 - total / max) * 100);

    let emoji, text;
    if (percent >= 80) {
        emoji = '🌟'; text = '你的心理状态非常好！继续保持积极的生活态度，同时也要记得关心身边人的情绪哦~';
    } else if (percent >= 60) {
        emoji = '🙂'; text = '整体状态不错！可能偶尔有些小波动，这是正常的。保持运动、社交和规律作息，你会更好~';
    } else if (percent >= 40) {
        emoji = '🤔'; text = '你可能正在经历一些压力或情绪波动。建议试试深呼吸、散步、或者找信任的人聊聊。记住：寻求帮助是一种力量。';
    } else if (percent >= 20) {
        emoji = '💜'; text = '看起来你最近承受了不少。请善待自己，给自己一些休息的时间。如果持续感到困扰，建议寻求专业心理咨询师的帮助。';
    } else {
        emoji = '🫂'; text = '你现在可能正在经历一段很难的时期。请记住：你不孤单。建议拨打心理援助热线 400-161-9995，或寻求专业心理帮助。寻求支持从来不是软弱的表现。';
    }

    document.getElementById('resultScore').textContent = `${emoji} ${percent}分`;
    document.getElementById('resultText').textContent = text;
}

// 初始化测试
startTest();

// ========== 心情记录 ==========
function selectMood(el) {
    document.querySelectorAll('.mood-emoji').forEach(e => e.classList.remove('selected'));
    el.classList.add('selected');
    selectedMood = el.dataset.mood;
}

function saveMood() {
    if (!selectedMood) {
        alert('请先选择一个心情表情~');
        return;
    }
    const note = document.getElementById('moodNote').value.trim();
    const moodEmojis = { great: '😄', good: '🙂', neutral: '😐', bad: '😔', terrible: '😢' };
    const now = new Date();
    const timeStr = `${now.getMonth()+1}/${now.getDate()} ${now.getHours()}:${String(now.getMinutes()).padStart(2,'0')}`;

    const item = { mood: selectedMood, emoji: moodEmojis[selectedMood], note, time: timeStr };
    let history = JSON.parse(localStorage.getItem('jijian_moods') || '[]');
    history.unshift(item);
    if (history.length > 30) history = history.slice(0, 30);
    localStorage.setItem('jijian_moods', JSON.stringify(history));

    document.getElementById('moodNote').value = '';
    document.querySelectorAll('.mood-emoji').forEach(e => e.classList.remove('selected'));
    selectedMood = null;

    // 更新顶部心情
    document.getElementById('moodIndicator').textContent = moodEmojis[item.mood];

    renderMoodHistory();
}

function renderMoodHistory() {
    const history = JSON.parse(localStorage.getItem('jijian_moods') || '[]');
    const list = document.getElementById('moodList');
    if (!list) return;
    if (history.length === 0) {
        list.innerHTML = '<p style="color:#8888aa;text-align:center;padding:20px;">还没有记录哦~</p>';
        return;
    }
    list.innerHTML = history.map(item => `
        <div class="mood-item">
            <span class="mood-item-emoji">${item.emoji}</span>
            <div class="mood-item-info">
                <div class="mood-item-time">${item.time}</div>
                ${item.note ? `<div class="mood-item-note">${item.note}</div>` : ''}
            </div>
        </div>
    `).join('');
}

renderMoodHistory();
