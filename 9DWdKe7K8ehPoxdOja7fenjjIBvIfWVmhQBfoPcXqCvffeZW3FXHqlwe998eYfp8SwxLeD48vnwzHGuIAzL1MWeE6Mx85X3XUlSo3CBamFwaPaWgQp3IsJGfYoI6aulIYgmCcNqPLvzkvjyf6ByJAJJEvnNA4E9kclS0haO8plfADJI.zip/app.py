from flask import Flask, render_template, request, jsonify
import os

app = Flask(__name__)

# 对话接口（本地规则引擎，无需API Key）
POSITIVE_KEYWORDS = ['开心', '高兴', '快乐', '好', '棒', '厉害', '不错', '可以', '幸福', '满足']
NEGATIVE_KEYWORDS = ['难过', '伤心', '焦虑', '压力', '烦', '累', '无聊', '孤独', '郁闷', '压抑', '不开心', '迷茫', '害怕', '担心', '崩溃', '绝望']

POSITIVE_REPLIES = [
    '太好了！🎉 能感受到你的积极能量，继续保持！你值得一切美好~',
    '你的好心情真的很有感染力呢！✨ 记住这种感觉，它是你最好的伙伴。',
    '听到你开心我也很开心！😊 好好享受这一刻，你配得上所有快乐！',
    '棒棒哒！🌟 快乐是一种能力，而你已经很擅长了~'
]

NEGATIVE_REPLIES = [
    '我能感受到你现在的状态 🫂 想告诉你：有这些感受是完全正常的，不需要对自己太苛刻。',
    '谢谢你愿意告诉我这些 💜 低谷只是暂时的，你比你想象的更坚强。',
    '你说的这些，很多人都在经历，但你选择说出来，这本身就是一种勇气 🌱',
    '嗯，我听到了 🤗 有时候，被看见、被理解就是最好的安慰。',
    '现在的你辛苦了 💙 深呼吸三次，告诉自己：这只是暂时的。'
]

DEFAULT_REPLIES = [
    '我在听呢 💚 继续说，我不会走开的。',
    '谢谢你和我分享 🌸 想聊什么都可以，我都在。',
    '嗯嗯，我理解 ✨ 你还有什么想说的吗？',
    '你说的我都记在心里了 💝 继续吧，我在~'
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    message = data.get('message', '').lower()

    import random
    if any(w in message for w in POSITIVE_KEYWORDS):
        reply = random.choice(POSITIVE_REPLIES)
    elif any(w in message for w in NEGATIVE_KEYWORDS):
        reply = random.choice(NEGATIVE_REPLIES)
    else:
        reply = random.choice(DEFAULT_REPLIES)

    return jsonify({'reply': reply})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
